﻿using Fusion;
using System;
using System.Collections.Generic;
using System.Text;

namespace Primal_Client.Mods
{
    internal class LongArms
    {
        public static void LongArmsMod()
        {
            GorillaLocomotion.GTPlayer.Instance.maxArmLength = 25f;
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 25f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 25f;
        }
    }
}
