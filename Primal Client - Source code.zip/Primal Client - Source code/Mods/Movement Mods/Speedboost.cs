﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Primal_Client.Mods
{
    internal class Speedboost
    {
        public static void SpeedBoostMod()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 9f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 9f;
        }
    }
}
