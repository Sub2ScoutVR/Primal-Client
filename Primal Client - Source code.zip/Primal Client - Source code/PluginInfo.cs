﻿namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "org.sub2scoutvr.gorillatag.menutemplate";
        public const string Name = "Primal Client";
        public const string Description = "Created by @sub2scoutvr with love <3";
        public const string Version = "1.0.1";
    }
}
